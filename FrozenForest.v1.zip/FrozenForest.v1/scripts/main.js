Events.run(EventType.ClientLoadEvent, () => {
    Events.run(EventType.SectorCaptureEvent, () => {
      Time.run(5, () => Vars.state.rules.disableWorldProcessors = false)
    })
  })